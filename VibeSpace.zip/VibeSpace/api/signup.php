<?php
include('database.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = $_POST['identifier'];
    $password = $_POST['password'];
    
    // Check if identifier is already in use
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :identifier OR phone = :identifier");
    $stmt->execute(['identifier' => $identifier]);
    if ($stmt->rowCount() > 0) {
        echo "Identifier already exists";
    } else {
        // Hash password and store user
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (email, password) VALUES (:identifier, :password)");
        $stmt->execute(['identifier' => $identifier, 'password' => $hashedPassword]);
        echo "Signup successful";
    }
}
?>
