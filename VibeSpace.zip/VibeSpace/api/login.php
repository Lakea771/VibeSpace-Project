<?php
include('database.php');

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = $_POST['identifier'];
    $password = $_POST['password'];
    
    // Fetch user by identifier
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :identifier OR phone = :identifier");
    $stmt->execute(['identifier' => $identifier]);
    $user = $stmt->fetch();
    
    // Check if user exists and password is correct
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        echo "Login successful";
    } else {
        echo "Invalid login credentials";
    }
}
?>
