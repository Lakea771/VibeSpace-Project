document.addEventListener('DOMContentLoaded', () => {
    const toggleFormText = document.getElementById('toggle-form');
    const signupForm = document.getElementById('signup-form');
    const loginForm = document.getElementById('login-form');
    const formTitle = document.getElementById('form-title');
    const passwordInput = document.getElementById('signup-password');
    const confirmPasswordInput = document.getElementById('signup-confirm-password');
    const passwordError = document.getElementById('password-error');

    // Toggle between Signup and Login form
    toggleFormText.addEventListener('click', () => {
        if (signupForm.style.display === 'none') {
            signupForm.style.display = 'block';
            loginForm.style.display = 'none';
            formTitle.textContent = 'Create a New Account';
            toggleFormText.textContent = 'Already have an account? Log In';
        } else {
            signupForm.style.display = 'none';
            loginForm.style.display = 'block';
            formTitle.textContent = 'Log In';
            toggleFormText.textContent = 'Don\'t have an account? Sign Up';
        }
    });

    // Client-side password confirmation
    signupForm.addEventListener('submit', function(event) {
        if (passwordInput.value !== confirmPasswordInput.value) {
            event.preventDefault();  // Prevent form submission
            passwordError.textContent = "Passwords do not match!";
        } else {
            passwordError.textContent = "";  // Clear any previous error
        }
    });
});
