<?php
define('SITE_NAME', 'VibeSpace');
define('BASE_URL', 'http://localhost/vibespace/');

?>
